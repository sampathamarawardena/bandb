CREATE PROCEDURE getRentings()
  BEGIN
	SELECT * 
    FROM rentitems a , images b 
    WHERE a.itemID = b.itemID 
	GROUP by a.itemID;
END;
